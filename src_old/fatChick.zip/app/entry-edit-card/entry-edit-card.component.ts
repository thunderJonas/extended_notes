import {Component, Input} from '@angular/core';

@Component({
  selector: 'app-entry-edit-card',
  templateUrl: './entry-edit-card.component.html',
  styleUrls: ['./entry-edit-card.component.scss'],
})
export class EntryEditCardComponent{
@Input() title: string;
@Input() description: string;
  constructor() {

  }

  public setTitle(title: string) {
    this.title = title;
  }

  public setDescription(desc: string) {
    this.description = desc;
  }

  public getTitle() {
    return this.title;
  }

  public getDescription() {
    return this.description;
  }
 deel(){
    document.getElementById('details').style.visibility = 'hidden';
 }

}
