import {Component, OnInit} from '@angular/core';
import {EntryEditCardComponent} from '../entry-edit-card/entry-edit-card.component';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],

}

)
export class HomePage implements OnInit {
  data: any;
  title = '';
  desc = '';


  constructor() {
  }

  ngOnInit() {
    fetch('./assets/data/daten.json').then(res => res.json())
      .then(json => {
        this.data = json;
      });
  }
  set() {
  this.title = 'pipp';
  this.desc = 'jgjg';
  document.getElementById('details').style.visibility = 'visible';
  }

  clicked(title: string, description: string){
    this.title = title;
    this.desc = description;

    document.getElementById('details').style.visibility = 'visible';
  }

  newEntry(){
    this.title = '';
    this.desc = '';

    document.getElementById('details').style.visibility = 'visible';
  }


}
