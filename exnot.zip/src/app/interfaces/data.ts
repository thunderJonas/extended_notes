export interface Data {
  id: string;
  title: string;
  content: string;
  emotion: number;
  emotionWeight: number;
  dateTime: any;
}

